﻿#include "imgui/imgui.h"
#include "imgui/imgui_impl_glfw.h"
#include "imgui/imgui_impl_opengl3.h"

#include "ShaderEditor.h"
#include "src/FlowGL/Shader.h"
#include "src/FlowGL/FlowGraphics.h"

ShaderEditor::ShaderEditor()
{

}

ShaderEditor::~ShaderEditor()
{

}

void ShaderEditor::Update()
{

}

void ShaderEditor::CreateShaderProgram()
{

}
