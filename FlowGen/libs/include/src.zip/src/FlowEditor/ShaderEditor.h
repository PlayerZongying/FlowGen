﻿#pragma once

class Shader;

class ShaderEditor
{
public:
    ShaderEditor();
    ~ShaderEditor();

    void Update();

    void CreateShaderProgram();

private:
};
