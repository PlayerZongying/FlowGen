﻿#pragma once


class MemoryHelper
{
public:
    static float CheckAvailableMemoryInMB();
    
};
