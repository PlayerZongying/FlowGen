﻿#include "IWritable.h"
