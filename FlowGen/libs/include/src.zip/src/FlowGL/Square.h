#pragma once

class Square
{
public:
    
};
