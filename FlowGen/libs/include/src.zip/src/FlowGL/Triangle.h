#pragma once

#pragma once
#include "Mesh.h"
class Triangle : public Mesh
{
public:
    Triangle();
};